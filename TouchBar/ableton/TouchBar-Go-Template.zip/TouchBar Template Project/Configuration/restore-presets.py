#!/usr/bin/env python3
"""Restore only the saved MIDI layout keys, preserving unrelated preferences."""
import argparse, datetime, pathlib, plistlib, subprocess, tempfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--apply',action='store_true',help='Write the saved layouts after quitting 3£ and MIDI Touchbar')
a=p.parse_args()
domain='ch.uebe.MIDI-Touchbar'
saved=plistlib.loads(pathlib.Path(__file__).with_name('TouchBar-MIDI-presets.plist').read_bytes())
print('Saved keys:',len(saved))
if not a.apply:
 print('Preview only. Quit 3£ and MIDI Touchbar, then run again with --apply. Matching saved preset keys will be replaced. Other preferences remain intact.')
 raise SystemExit()
for name in ['MusicStrip','MIDI Touchbar']:
 if subprocess.run(['pgrep','-x',name],stdout=subprocess.DEVNULL).returncode==0:
  raise SystemExit('Quit 3£ and MIDI Touchbar before restoring.')
r=subprocess.run(['defaults','export',domain,'-'],capture_output=True)
if r.returncode:
 raise SystemExit('Could not export current preferences. Open and quit 3£ once, then retry. Nothing changed.')
current=plistlib.loads(r.stdout)
backup=pathlib.Path(__file__).parent/('before-restore-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.plist')
backup.write_bytes(r.stdout)
current.update(saved)
with tempfile.TemporaryDirectory() as tmp:
 f=pathlib.Path(tmp)/'merged.plist';f.write_bytes(plistlib.dumps(current))
 subprocess.run(['defaults','import',domain,str(f)],check=True)
print('Restored. Previous preferences:',backup)
print('Reopen 3£. Re-select MIDI ports in Live if needed on a different Mac.')
