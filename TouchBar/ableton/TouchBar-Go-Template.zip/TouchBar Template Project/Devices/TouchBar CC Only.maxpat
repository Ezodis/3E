{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 0,
      "revision": 7,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [
      0,
      0,
      600,
      250
    ],
    "openrect": [
      0,
      0,
      600,
      169
    ],
    "default_fontsize": 10.0,
    "default_fontname": "Arial Bold",
    "gridsize": [
      8.0,
      8.0
    ],
    "boxanimatetime": 500,
    "boxes": [
      {
        "box": {
          "id": "title",
          "maxclass": "comment",
          "text": "CC1\u2013CC4 ONLY \u2192 DRUMS. Piano notes are blocked. Keep Monitor In.",
          "patching_rect": [
            15,
            10,
            550,
            24
          ],
          "presentation": 1,
          "presentation_rect": [
            15,
            10,
            550,
            24
          ]
        }
      },
      {
        "box": {
          "id": "in1",
          "maxclass": "newobj",
          "text": "ctlin 1",
          "patching_rect": [
            105,
            70,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "out1",
          "maxclass": "newobj",
          "text": "ctlout 1",
          "patching_rect": [
            105,
            130,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "in2",
          "maxclass": "newobj",
          "text": "ctlin 2",
          "patching_rect": [
            210,
            70,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "out2",
          "maxclass": "newobj",
          "text": "ctlout 2",
          "patching_rect": [
            210,
            130,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "in3",
          "maxclass": "newobj",
          "text": "ctlin 3",
          "patching_rect": [
            315,
            70,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "out3",
          "maxclass": "newobj",
          "text": "ctlout 3",
          "patching_rect": [
            315,
            130,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "in4",
          "maxclass": "newobj",
          "text": "ctlin 4",
          "patching_rect": [
            420,
            70,
            90,
            22
          ]
        }
      },
      {
        "box": {
          "id": "out4",
          "maxclass": "newobj",
          "text": "ctlout 4",
          "patching_rect": [
            420,
            130,
            90,
            22
          ]
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "in1",
            0
          ],
          "destination": [
            "out1",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "in2",
            0
          ],
          "destination": [
            "out2",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "in3",
            0
          ],
          "destination": [
            "out3",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "in4",
            0
          ],
          "destination": [
            "out4",
            0
          ]
        }
      }
    ],
    "dependency_cache": [],
    "latency": 0,
    "is_mpe": 0,
    "external_mpe_tuning_enabled": 0,
    "minimum_live_version": "",
    "minimum_max_version": "",
    "platform_compatibility": 0,
    "project": {
      "version": 1,
      "creationdate": 3590052786,
      "modificationdate": 3590052786,
      "viewrect": [
        0.0,
        0.0,
        300.0,
        500.0
      ],
      "autoorganize": 1,
      "hideprojectwindow": 1,
      "showdependencies": 1,
      "autolocalize": 0,
      "contents": {
        "patchers": {}
      },
      "layout": {},
      "searchpath": {},
      "detailsvisible": 0,
      "amxdtype": 1835887981,
      "readonly": 0,
      "devpathtype": 0,
      "devpath": ".",
      "sortmode": 0,
      "viewmode": 0,
      "includepackages": 0
    },
    "autosave": 0,
    "oscreceiveudpport": 0,
    "openinpresentation": 1
  }
}